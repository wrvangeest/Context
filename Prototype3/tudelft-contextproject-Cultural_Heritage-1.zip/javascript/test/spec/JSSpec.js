describe("Javascript functions", function () {
	describe("Video functions", function () {

	});

	describe("Misc functions", function () {
		it("checkTime should stop", function() {
			
		});

	});

	describe("Tag functions", function () {
		it("")
	});
});