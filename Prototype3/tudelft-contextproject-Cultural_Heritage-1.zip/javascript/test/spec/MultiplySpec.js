describe("Javascript functions", function () {
	describe("Video functions", function () {

	});

	describe("Misc functions", function () {
		it("Skiptime should ")

	});

	describe("Tag functions", function () {

	});

	it("2 x 2 = 4", function () {
		var result = multiply(2,2);
		expect(result).toEqual(4);
	});
});