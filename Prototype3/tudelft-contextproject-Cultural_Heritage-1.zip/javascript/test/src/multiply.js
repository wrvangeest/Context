function multiply(x, y) {
	return (x * y);
}